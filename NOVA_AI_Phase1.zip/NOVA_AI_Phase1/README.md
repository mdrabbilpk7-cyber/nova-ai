# NOVA AI — Phase 1

A responsive, dark-premium AI assistant interface. This first phase is a front-end prototype: chat messages appear locally and receive a demo response. It is **not connected to a real AI model yet**.

## Files
- `index.html` — app structure
- `style.css` — dark premium responsive design
- `app.js` — chat UI, language switching, demo replies
- `manifest.json` and `sw.js` — basic PWA setup

## Run on a computer
1. Extract the ZIP file.
2. Open the `NOVA_AI_Phase1` folder.
3. Double-click `index.html` to preview in Chrome or Edge.
4. For PWA/offline testing, host it on HTTPS (for example, GitHub Pages).

## Run on Android
1. Upload the extracted files to a GitHub repository.
2. Enable GitHub Pages in repository Settings → Pages.
3. Open the published HTTPS website in Chrome on Android.
4. Chrome menu (⋮) → Add to Home screen / Install app.

## Next phase
Connect a real AI API through a secure backend/serverless function. Never put a private API key in `app.js`, `index.html`, or any public repository.

## Notes
- Google Fonts are used when internet is available; local fallback fonts are included.
- The interface includes Bengali, English, French, Spanish, and Hindi UI translations.
- AI-generated answers, voice, image generation, accounts, and payments are not implemented in Phase 1.
