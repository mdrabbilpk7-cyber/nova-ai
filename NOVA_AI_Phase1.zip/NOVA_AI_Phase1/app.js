const translations = {
 bn:{newChat:"নতুন চ্যাট",workspace:"WORKSPACE",assistant:"AI Assistant",language:"ভাষা / Language",freePlan:"ফ্রি প্ল্যান",hello:"হ্যালো!",welcomeTitle:"আমি কীভাবে সাহায্য করতে পারি?",welcomeText:"প্রশ্ন করুন, নতুন কিছু শিখুন, লিখুন বা আপনার আইডিয়া নিয়ে কাজ শুরু করুন।",suggest1:"ইংরেজি শেখার পরিকল্পনা",suggest2:"সোশ্যাল মিডিয়া পোস্ট",suggest3:"AI সম্পর্কে জানুন",suggest4:"দৈনিক রুটিন তৈরি",placeholder:"এখানে আপনার প্রশ্ন লিখুন...",hint:"NOVA AI এখনো সেটআপ পর্যায়ে",disclaimer:"NOVA AI ভুল করতে পারে। গুরুত্বপূর্ণ তথ্য যাচাই করে নিন।",demo:"আপনার বার্তা পেয়েছি! 😊 এটি NOVA AI-এর প্রথম ডিজাইন সংস্করণ। আসল AI উত্তর চালু করতে পরের ধাপে AI API সংযুক্ত করতে হবে।"},
 en:{newChat:"New chat",workspace:"WORKSPACE",assistant:"AI Assistant",language:"Language",freePlan:"Free Plan",hello:"Hello!",welcomeTitle:"How can I help you today?",welcomeText:"Ask a question, learn something new, write, or start working on an idea.",suggest1:"English learning plan",suggest2:"Social media post",suggest3:"Learn about AI",suggest4:"Create a daily routine",placeholder:"Type your message here...",hint:"NOVA AI is in setup mode",disclaimer:"NOVA AI can make mistakes. Please verify important information.",demo:"I received your message! 😊 This is the first interface version of NOVA AI. Connect an AI API in the next phase to receive real AI responses."},
 fr:{newChat:"Nouvelle discussion",workspace:"ESPACE DE TRAVAIL",assistant:"Assistant IA",language:"Langue",freePlan:"Offre gratuite",hello:"Bonjour !",welcomeTitle:"Comment puis-je vous aider ?",welcomeText:"Posez une question, apprenez, écrivez ou développez une idée.",suggest1:"Apprendre l’anglais",suggest2:"Publication sociale",suggest3:"Découvrir l’IA",suggest4:"Créer une routine",placeholder:"Écrivez votre message...",hint:"NOVA AI est en configuration",disclaimer:"NOVA AI peut faire des erreurs. Vérifiez les informations importantes.",demo:"Message reçu ! 😊 Ceci est la première version de NOVA AI. Connectez une API IA à l’étape suivante pour obtenir de vraies réponses."},
 es:{newChat:"Nuevo chat",workspace:"ESPACIO DE TRABAJO",assistant:"Asistente IA",language:"Idioma",freePlan:"Plan gratuito",hello:"¡Hola!",welcomeTitle:"¿Cómo puedo ayudarte?",welcomeText:"Pregunta, aprende algo nuevo, escribe o desarrolla una idea.",suggest1:"Plan para aprender inglés",suggest2:"Publicación social",suggest3:"Conocer la IA",suggest4:"Crear rutina diaria",placeholder:"Escribe tu mensaje aquí...",hint:"NOVA AI está en configuración",disclaimer:"NOVA AI puede cometer errores. Verifica la información importante.",demo:"¡He recibido tu mensaje! 😊 Esta es la primera versión de NOVA AI. Conecta una API de IA en la siguiente fase para obtener respuestas reales."},
 hi:{newChat:"नई चैट",workspace:"कार्यस्थल",assistant:"AI सहायक",language:"भाषा",freePlan:"मुफ़्त योजना",hello:"नमस्ते!",welcomeTitle:"मैं आपकी कैसे मदद कर सकता हूँ?",welcomeText:"सवाल पूछें, कुछ नया सीखें, लिखें या अपने विचार पर काम करें।",suggest1:"अंग्रेज़ी सीखने की योजना",suggest2:"सोशल मीडिया पोस्ट",suggest3:"AI के बारे में जानें",suggest4:"दैनिक दिनचर्या",placeholder:"अपना संदेश लिखें...",hint:"NOVA AI अभी सेटअप में है",disclaimer:"NOVA AI गलतियाँ कर सकता है। महत्वपूर्ण जानकारी जाँच लें।",demo:"आपका संदेश मिल गया! 😊 यह NOVA AI का पहला इंटरफ़ेस संस्करण है। असली AI जवाबों के लिए अगले चरण में AI API जोड़ें।"}
};
const $ = s => document.querySelector(s);
const messages = $("#messages"), welcome = $("#welcome"), input = $("#messageInput");
let lang = "bn";
function toast(msg){const t=$("#toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2200)}
function applyLanguage(code){lang=code;const t=translations[code]||translations.en;document.documentElement.lang=code;
 document.querySelectorAll("[data-i18n]").forEach(el=>{const k=el.dataset.i18n;if(t[k])el.textContent=t[k]});
 document.querySelectorAll("[data-i18n-placeholder]").forEach(el=>{const k=el.dataset.i18nPlaceholder;if(t[k])el.placeholder=t[k]});
}
function addMessage(text,who){welcome.style.display="none";const row=document.createElement("div");row.className=`message ${who}`;
 const icon=document.createElement("div");icon.className="message-icon";icon.textContent=who==="user"?"You":"✦";
 const bubble=document.createElement("div");bubble.className="bubble";bubble.textContent=text;row.append(icon,bubble);messages.append(row);row.scrollIntoView({behavior:"smooth",block:"end"});
}
function send(text){const value=(text||input.value).trim();if(!value)return;addMessage(value,"user");input.value="";input.style.height="auto";setTimeout(()=>addMessage((translations[lang]||translations.en).demo,"assistant"),350)}
$("#chatForm").addEventListener("submit",e=>{e.preventDefault();send()});
input.addEventListener("input",()=>{input.style.height="auto";input.style.height=Math.min(input.scrollHeight,130)+"px"});
document.querySelectorAll(".suggestion").forEach(b=>b.addEventListener("click",()=>send(b.dataset.prompt)));
$("#newChat").addEventListener("click",()=>{messages.innerHTML="";welcome.style.display="flex";$("#sidebar").classList.remove("open");input.focus()});
$("#clearChat").addEventListener("click",()=>{messages.innerHTML="";welcome.style.display="flex";toast(lang==="bn"?"চ্যাট পরিষ্কার হয়েছে":"Chat cleared")});
$("#languageSelect").addEventListener("change",e=>applyLanguage(e.target.value));
$("#languageShortcut").addEventListener("click",()=>{$("#languageSelect").focus();$("#languageSelect").click()});
$("#menuBtn").addEventListener("click",()=>$("#sidebar").classList.toggle("open"));
if("serviceWorker" in navigator && location.protocol.startsWith("http"))navigator.serviceWorker.register("./sw.js").catch(()=>{});
